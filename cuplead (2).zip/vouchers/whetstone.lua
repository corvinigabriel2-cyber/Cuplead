
SMODS.Voucher {
    key = 'whetstone',
    pos = { x = 5, y = 0 },
    loc_txt = {
        name = 'Whetstone',
        text = {
            [1] = 'Ao comprar ganha uma cópia {C:enhanced}Laminada{}',
            [2] = 'do coringa {C:uncommon}Carla Maria{}.'
        },
        unlock = {
            [1] = 'Unlocked by default.'
        }
    },
    cost = 10,
    unlocked = true,
    discovered = true,
    no_collection = false,
    can_repeat_soul = false,
    requires = {'smoke_bomb'},
    atlas = 'CustomVouchers',
    redeem = function(self, card)
    end
}