
SMODS.Voucher {
    key = 'heart',
    pos = { x = 0, y = 0 },
    config = { 
        extra = {
            hands0 = 1,
            hands = 2
        } 
    },
    loc_txt = {
        name = 'Heart',
        text = {
            [1] = 'Ao derrotar um {C:attention}Blind de Chefe{}, {C:blue}+1{} mão a cada rodada.',
            [2] = 'Quando tiver {C:attention}7{} mãos ou mais, {C:red}-2{} mãos por rodada.'
        },
        unlock = {
            [1] = 'Unlocked by default.'
        }
    },
    cost = 10,
    unlocked = true,
    discovered = true,
    no_collection = false,
    can_repeat_soul = false,
    atlas = 'CustomVouchers',
    calculate = function(self, card, context)
        if context.end_of_round and context.main_eval and G.GAME.blind.boss then
            G.GAME.round_resets.hands = G.GAME.round_resets.hands + 1
            ease_hands_played(1)
        end
        if context.end_of_round and context.main_eval and G.GAME.blind.boss then
            if to_big(G.GAME.current_round.hands_left) >= to_big(7) then
                G.GAME.round_resets.hands = G.GAME.round_resets.hands - 2
                ease_hands_played(-2)
            end
        end
    end
}