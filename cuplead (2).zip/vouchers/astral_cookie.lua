
SMODS.Voucher {
    key = 'astral_cookie',
    pos = { x = 6, y = 0 },
    loc_txt = {
        name = 'Astral Cookie',
        text = {
            [1] = '{C:attention}+2{} tamanho de mão.',
            [2] = '{C:red}-1{} de descarte.'
        },
        unlock = {
            [1] = 'Unlocked by default.'
        }
    },
    cost = 10,
    unlocked = true,
    discovered = true,
    no_collection = false,
    can_repeat_soul = false,
    atlas = 'CustomVouchers',
    
}