
SMODS.Voucher {
    key = 'heart_ring',
    pos = { x = 7, y = 0 },
    config = { 
        extra = {
            dollars0 = 1
        } 
    },
    loc_txt = {
        name = 'Heart Ring',
        text = {
            [1] = 'Ao abrir um {C:attention}pacote{} ganha +{C:money}$1{}.'
        },
        unlock = {
            [1] = 'Unlocked by default.'
        }
    },
    cost = 10,
    unlocked = true,
    discovered = true,
    no_collection = false,
    can_repeat_soul = false,
    requires = {'astral_cookie'},
    atlas = 'CustomVouchers',
    calculate = function(self, card, context)
        if context.open_booster then
            return {
                
                func = function()
                    
                    local current_dollars = G.GAME.dollars
                    local target_dollars = G.GAME.dollars + 1
                    local dollar_value = target_dollars - current_dollars
                    ease_dollars(dollar_value, true)
                    card_eval_status_text(card, 'extra', nil, nil, nil, {message = "+"..tostring(1), colour = G.C.MONEY})
                    return true
                end
            }
        end
    end
}