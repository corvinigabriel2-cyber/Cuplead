
SMODS.Voucher {
    key = 'p_shugar',
    pos = { x = 3, y = 0 },
    config = { 
        extra = {
            discard_size0 = 1
        } 
    },
    loc_txt = {
        name = 'P. Shugar',
        text = {
            [1] = '{C:attention}+1{} tamanho de descarte'
        },
        unlock = {
            [1] = 'Unlocked by default.'
        }
    },
    cost = 10,
    unlocked = true,
    discovered = true,
    no_collection = false,
    can_repeat_soul = false,
    atlas = 'CustomVouchers',
    redeem = function(self, card)
        return {
            
            G.E_MANAGER:add_event(Event({
                func = function()
                    
                    
                    SMODS.change_discard_limit(1)
                    return true
                end
            }))
        }
    end
}