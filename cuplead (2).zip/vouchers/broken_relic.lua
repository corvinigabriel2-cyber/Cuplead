
SMODS.Voucher {
    key = 'broken_relic',
    pos = { x = 8, y = 0 },
    config = { 
        extra = {
            hands0 = 1,
            hand_size0 = 1,
            discards0 = 1
        } 
    },
    loc_txt = {
        name = 'Broken Relic',
        text = {
            [1] = '{C:red}-1{} descarte.',
            [2] = '{C:red}-1{} tamanho de mão.',
            [3] = '{C:red}-1{} mão por rodada.'
        },
        unlock = {
            [1] = 'Unlocked by default.'
        }
    },
    cost = 10,
    unlocked = true,
    discovered = true,
    no_collection = false,
    can_repeat_soul = false,
    atlas = 'CustomVouchers',
    redeem = function(self, card)
        G.GAME.round_resets.hands = G.GAME.round_resets.hands - 1
        ease_hands_played(-1)
        G.GAME.round_resets.discards = G.GAME.round_resets.discards - 1
        ease_discard(-1)
        return {
            
            G.E_MANAGER:add_event(Event({
                func = function()
                    
                    
                    G.hand:change_size(-1)
                    return true
                end
            }))
        }
    end
}