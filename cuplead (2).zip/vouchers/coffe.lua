
SMODS.Voucher {
    key = 'coffe',
    pos = { x = 4, y = 0 },
    config = { 
        extra = {
            discard_size0 = 1,
            all_blinds_size0 = 1.25
        } 
    },
    loc_txt = {
        name = 'Coffe',
        text = {
            [1] = '{C:attention}+1{} tamanho de descarte. Pontuação',
            [2] = 'Max do {C:attention}Blind{} dividido em {X:attention,C:white}/1.25{}.'
        },
        unlock = {
            [1] = 'Unlocked by default.'
        }
    },
    cost = 10,
    unlocked = true,
    discovered = true,
    no_collection = false,
    can_repeat_soul = false,
    requires = {'p_shugar'},
    atlas = 'CustomVouchers',
    redeem = function(self, card)
        G.E_MANAGER:add_event(Event({
            func = function()
                G.GAME.starting_params.ante_scaling = G.GAME.starting_params.ante_scaling / 1.25
                return true
            end
        }))
        return {
            
            G.E_MANAGER:add_event(Event({
                func = function()
                    
                    
                    SMODS.change_discard_limit(1)
                    return true
                end
            }))
        }
    end
}