
SMODS.Voucher {
    key = 'twin_heart',
    pos = { x = 1, y = 0 },
    config = { 
        extra = {
            hands0 = 1,
            hand_size0 = 1
        } 
    },
    loc_txt = {
        name = 'Twin Heart',
        text = {
            [1] = '{C:blue}+1{} mão por rodada.',
            [2] = '{C:red}-1{} tamanho de mão.'
        },
        unlock = {
            [1] = 'Unlocked by default.'
        }
    },
    cost = 10,
    unlocked = true,
    discovered = true,
    no_collection = false,
    can_repeat_soul = false,
    requires = {'heart'},
    atlas = 'CustomVouchers',
    redeem = function(self, card)
        G.GAME.round_resets.hands = G.GAME.round_resets.hands + 1
        ease_hands_played(1)
        return {
            
            G.E_MANAGER:add_event(Event({
                func = function()
                    
                    
                    G.hand:change_size(-1)
                    return true
                end
            }))
        }
    end
}