
SMODS.Voucher {
    key = 'cursed_relic',
    pos = { x = 9, y = 0 },
    config = { 
        extra = {
            hands0 = 2,
            hand_size0 = 2,
            discards0 = 2
        } 
    },
    loc_txt = {
        name = 'Cursed Relic',
        text = {
            [1] = '{C:attention}+2{} descartes.',
            [2] = '{C:attention}+2{} tamanho de mão.',
            [3] = '{C:attention}+2{} mão por rodada.'
        },
        unlock = {
            [1] = 'Unlocked by default.'
        }
    },
    cost = 10,
    unlocked = true,
    discovered = true,
    no_collection = false,
    can_repeat_soul = false,
    requires = {'broken_relic'},
    atlas = 'CustomVouchers',
    redeem = function(self, card)
        G.GAME.round_resets.hands = G.GAME.round_resets.hands + 2
        ease_hands_played(2)
        G.GAME.round_resets.discards = G.GAME.round_resets.discards + 2
        ease_discard(2)
        return {
            
            G.E_MANAGER:add_event(Event({
                func = function()
                    
                    
                    G.hand:change_size(2)
                    return true
                end
            }))
        }
    end
}