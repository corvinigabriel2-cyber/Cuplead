
SMODS.Voucher {
    key = 'smoke_bomb',
    pos = { x = 2, y = 0 },
    config = { 
        extra = {
            ante_value0 = 1,
            dollars0 = 5
        } 
    },
    loc_txt = {
        name = 'Smoke Bomb',
        text = {
            [1] = '{C:attention}+1{} Aposta. Ao derrotar um',
            [2] = '{C:attention}Blind de Chefe{} ganha +{C:money}$5{}.'
        },
        unlock = {
            [1] = 'Unlocked by default.'
        }
    },
    cost = 10,
    unlocked = true,
    discovered = true,
    no_collection = false,
    can_repeat_soul = false,
    atlas = 'CustomVouchers',
    calculate = function(self, card, context)
        if context.end_of_round and context.main_eval and G.GAME.blind.boss then
            return {
                
                func = function()
                    
                    local current_dollars = G.GAME.dollars
                    local target_dollars = G.GAME.dollars + 5
                    local dollar_value = target_dollars - current_dollars
                    ease_dollars(dollar_value, true)
                    card_eval_status_text(card, 'extra', nil, nil, nil, {message = "+"..tostring(5), colour = G.C.MONEY})
                    return true
                end
            }
        end
    end, redeem = function(self, card)
        local mod = 1
        ease_ante(mod)
        G.GAME.round_resets.blind_ante = G.GAME.round_resets.blind_ante + mod
    end
}