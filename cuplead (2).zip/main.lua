SMODS.Atlas({
    key = "modicon", 
    path = "ModIcon.png", 
    px = 34,
    py = 34,
    atlas_table = "ASSET_ATLAS"
})

SMODS.Atlas({
    key = "balatro", 
    path = "balatro.png", 
    px = 333,
    py = 216,
    prefix_config = { key = false },
    atlas_table = "ASSET_ATLAS"
})


SMODS.Atlas({
    key = "CustomJokers", 
    path = "CustomJokers.png", 
    px = 71,
    py = 95, 
    atlas_table = "ASSET_ATLAS"
})

SMODS.Atlas({
    key = "CustomConsumables", 
    path = "CustomConsumables.png", 
    px = 71,
    py = 95, 
    atlas_table = "ASSET_ATLAS"
})

SMODS.Atlas({
    key = "CustomBoosters", 
    path = "CustomBoosters.png", 
    px = 71,
    py = 95, 
    atlas_table = "ASSET_ATLAS"
})

SMODS.Atlas({
    key = "CustomVouchers", 
    path = "CustomVouchers.png", 
    px = 71,
    py = 95, 
    atlas_table = "ASSET_ATLAS"
})

local NFS = require("nativefs")
to_big = to_big or function(a) return a end
lenient_bignum = lenient_bignum or function(a) return a end
-- this function is used to load everything within a folder.-- Jokerforge doesnt use it because it doesnt make loading order easy
local function load_folder(path)
    local files = NFS.getDirectoryItemsInfo(mod_path .. "/" .. path)
    for i = 1, #files do
        local file_name = files[i].name
        if file_name:sub(-4) == ".lua" then
            assert(SMODS.load_file(path .. file_name))()
        end
    end
end
-- load the jokers
if true then
    assert(SMODS.load_file("jokers/therootpack.lua"))()
    assert(SMODS.load_file("jokers/goopylegrande.lua"))()
    assert(SMODS.load_file("jokers/hildaberg.lua"))()
    assert(SMODS.load_file("jokers/cagneycarnation.lua"))()
    assert(SMODS.load_file("jokers/ribbyandcroaks.lua"))()
    assert(SMODS.load_file("jokers/baronessvonbonbon.lua"))()
    assert(SMODS.load_file("jokers/beppitheclown.lua"))()
    assert(SMODS.load_file("jokers/djimmithegreat.lua"))()
    assert(SMODS.load_file("jokers/grimmatchstick.lua"))()
    assert(SMODS.load_file("jokers/wallywarbles.lua"))()
    assert(SMODS.load_file("jokers/rumorhoneybottoms.lua"))()
    assert(SMODS.load_file("jokers/captainbrineybeard.lua"))()
    assert(SMODS.load_file("jokers/sallystageplay.lua"))()
    assert(SMODS.load_file("jokers/wernerwerman.lua"))()
    assert(SMODS.load_file("jokers/drkahlsrobot.lua"))()
    assert(SMODS.load_file("jokers/carlamaria.lua"))()
    assert(SMODS.load_file("jokers/phantomexpress.lua"))()
    assert(SMODS.load_file("jokers/kingdice.lua"))()
    assert(SMODS.load_file("jokers/thedevil.lua"))()
    assert(SMODS.load_file("jokers/glumstonethegiant.lua"))()
    assert(SMODS.load_file("jokers/moonshinemob.lua"))()
    assert(SMODS.load_file("jokers/thehowlingaces.lua"))()
    assert(SMODS.load_file("jokers/mortimerfreeze.lua"))()
    assert(SMODS.load_file("jokers/estherwinchester.lua"))()
    assert(SMODS.load_file("jokers/chefsaltbaker.lua"))()
end
-- load the consumables
if true then
    assert(SMODS.load_file("consumables/peashooter.lua"))()
    assert(SMODS.load_file("consumables/spread.lua"))()
    assert(SMODS.load_file("consumables/chaser.lua"))()
    assert(SMODS.load_file("consumables/lobber.lua"))()
    assert(SMODS.load_file("consumables/roundabout.lua"))()
    assert(SMODS.load_file("consumables/charge.lua"))()
    assert(SMODS.load_file("consumables/crackshot.lua"))()
    assert(SMODS.load_file("consumables/converge.lua"))()
end
-- load the vouchers
if true then
    assert(SMODS.load_file("vouchers/heart.lua"))()
    assert(SMODS.load_file("vouchers/twin_heart.lua"))()
    assert(SMODS.load_file("vouchers/smoke_bomb.lua"))()
    assert(SMODS.load_file("vouchers/p_shugar.lua"))()
    assert(SMODS.load_file("vouchers/coffe.lua"))()
    assert(SMODS.load_file("vouchers/whetstone.lua"))()
    assert(SMODS.load_file("vouchers/astral_cookie.lua"))()
    assert(SMODS.load_file("vouchers/heart_ring.lua"))()
    assert(SMODS.load_file("vouchers/broken_relic.lua"))()
    assert(SMODS.load_file("vouchers/cursed_relic.lua"))()
end



assert(SMODS.load_file("rarities.lua"))()


-- load boosters
assert(SMODS.load_file("boosters.lua"))()
SMODS.ObjectType({
    key = "cuplead_food",
    cards = {
        ["j_gros_michel"] = true,
        ["j_egg"] = true,
        ["j_ice_cream"] = true,
        ["j_cavendish"] = true,
        ["j_turtle_bean"] = true,
        ["j_diet_cola"] = true,
        ["j_popcorn"] = true,
        ["j_ramen"] = true,
        ["j_selzer"] = true
    },
})

SMODS.ObjectType({
    key = "cuplead_mycustom_jokers",
    cards = {
        ["j_cuplead_therootpack"] = true,
        ["j_cuplead_goopylegrande"] = true,
        ["j_cuplead_hildaberg"] = true,
        ["j_cuplead_cagneycarnation"] = true,
        ["j_cuplead_ribbyandcroaks"] = true,
        ["j_cuplead_baronessvonbonbon"] = true,
        ["j_cuplead_beppitheclown"] = true,
        ["j_cuplead_djimmithegreat"] = true,
        ["j_cuplead_grimmatchstick"] = true,
        ["j_cuplead_wallywarbles"] = true,
        ["j_cuplead_rumorhoneybottoms"] = true,
        ["j_cuplead_captainbrineybeard"] = true,
        ["j_cuplead_sallystageplay"] = true,
        ["j_cuplead_wernerwerman"] = true,
        ["j_cuplead_drkahlsrobot"] = true,
        ["j_cuplead_carlamaria"] = true,
        ["j_cuplead_phantomexpress"] = true,
        ["j_cuplead_kingdice"] = true,
        ["j_cuplead_thedevil"] = true
    },
})

SMODS.ObjectType({
    key = "cuplead_cuplead_jokers",
    cards = {
        ["j_cuplead_glumstonethegiant"] = true,
        ["j_cuplead_moonshinemob"] = true,
        ["j_cuplead_thehowlingaces"] = true,
        ["j_cuplead_mortimerfreeze"] = true,
        ["j_cuplead_estherwinchester"] = true,
        ["j_cuplead_chefsaltbaker"] = true
    },
})


SMODS.current_mod.optional_features = function()
    return {
        cardareas = {} 
    }
end