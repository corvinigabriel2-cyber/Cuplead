SMODS.Rarity {
    key = "ilha_1",
    pools = {
        ["Joker"] = true
    },
    default_weight = 0.5,
    badge_colour = HEX('848484'),
    loc_txt = {
        name = "Ilha 1"
    },
    get_weight = function(self, weight, object_type)
        return weight
    end,
}

SMODS.Rarity {
    key = "ilha_2",
    pools = {
        ["Joker"] = true
    },
    default_weight = 0.12,
    badge_colour = HEX('6d850b'),
    loc_txt = {
        name = "Ilha 2"
    },
    get_weight = function(self, weight, object_type)
        return weight
    end,
}

SMODS.Rarity {
    key = "ilha_3",
    pools = {
        ["Joker"] = true
    },
    default_weight = 0.06,
    badge_colour = HEX('329447'),
    loc_txt = {
        name = "Ilha 3"
    },
    get_weight = function(self, weight, object_type)
        return weight
    end,
}

SMODS.Rarity {
    key = "ilha_infernal",
    pools = {
        ["Joker"] = true
    },
    default_weight = 0.03,
    badge_colour = HEX('ff0017'),
    loc_txt = {
        name = "Ilha Infernal"
    },
    get_weight = function(self, weight, object_type)
        return weight
    end,
}

SMODS.Rarity {
    key = "ilha_4",
    pools = {
        ["Joker"] = true
    },
    default_weight = 0.03,
    badge_colour = HEX('16b19f'),
    loc_txt = {
        name = "Ilha 4"
    },
    get_weight = function(self, weight, object_type)
        return weight
    end,
}