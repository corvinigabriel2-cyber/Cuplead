
SMODS.Joker{ --Baroness Von Bon Bon
    key = "baronessvonbonbon",
    config = {
        extra = {
            B = 10,
            tarotcardsused = 10
        }
    },
    loc_txt = {
        ['name'] = 'Baroness Von Bon Bon',
        ['text'] = {
            [1] = '{C:blue}+10{} Fichas para cada carta',
            [2] = 'de {C:tarot}Tarot{} usada.',
            [3] = '{C:inactive}(Atualmente: {C:chips}+#1#{} {C:inactive}Fichas){}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 5,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = "cuplead_ilha_2",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["cuplead_mycustom_jokers"] = true },
    
    loc_vars = function(self, info_queue, card)
        
        return {vars = {card.ability.extra.B, card.ability.extra.tarotcardsused + (((G.GAME.consumeable_usage_total and G.GAME.consumeable_usage_total.tarot or 0) or 0)) * 10}}
    end,
    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            return {
                chips = card.ability.extra.tarotcardsused + ((G.GAME.consumeable_usage_total and G.GAME.consumeable_usage_total.tarot or 0)) * 10
            }
        end
        if context.after and context.cardarea == G.jokers  then
            return {
                func = function()
                    card.ability.extra.B = ((G.GAME.consumeable_usage_total and G.GAME.consumeable_usage_total.tarot or 0)) * 10
                    return true
                end
            }
        end
    end
}