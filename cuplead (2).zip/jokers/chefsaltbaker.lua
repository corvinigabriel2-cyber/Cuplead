
SMODS.Joker{ --Chef Saltbaker
    key = "chefsaltbaker",
    config = {
        extra = {
            D = 1,
            planetcardsused = 1
        }
    },
    loc_txt = {
        ['name'] = 'Chef Saltbaker',
        ['text'] = {
            [1] = 'Ganha {X:red,C:white}X0.25{} Mult para cada',
            [2] = 'carta de {C:planet}Planeta{} ultilizada.',
            [3] = '{C:inactive}(Atualmente: {}{X:mult,C:white} X#1# {} {C:inactive} Mult){}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 4,
        y = 2
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 10,
    rarity = "cuplead_ilha_4",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["cuplead_cuplead_jokers"] = true },
    
    loc_vars = function(self, info_queue, card)
        
        return {vars = {card.ability.extra.D, card.ability.extra.planetcardsused + (((G.GAME.consumeable_usage_total and G.GAME.consumeable_usage_total.planet or 0) or 0)) * 0.25}}
    end,
    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            return {
                Xmult = card.ability.extra.planetcardsused + ((G.GAME.consumeable_usage_total and G.GAME.consumeable_usage_total.planet or 0)) * 0.25
            }
        end
        if context.after and context.cardarea == G.jokers  then
            return {
                func = function()
                    card.ability.extra.D = ((G.GAME.consumeable_usage_total and G.GAME.consumeable_usage_total.planet or 0)) * 0.25
                    return true
                end
            }
        end
    end
}