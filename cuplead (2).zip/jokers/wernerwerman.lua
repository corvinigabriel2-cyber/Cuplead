
SMODS.Joker{ --Werner Werman
    key = "wernerwerman",
    config = {
        extra = {
            chips0 = 10,
            mult0 = 2
        }
    },
    loc_txt = {
        ['name'] = 'Werner Werman',
        ['text'] = {
            [1] = 'Cartas com classe {C:attention}par{} dão {C:blue}+10{} Fichas',
            [2] = 'e {C:red}+2{} Multi quando pontuadas.'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 3,
        y = 1
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 6,
    rarity = "cuplead_ilha_3",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["cuplead_mycustom_jokers"] = true },
    
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if (context.other_card:get_id() == 2 or context.other_card:get_id() == 4 or context.other_card:get_id() == 6 or context.other_card:get_id() == 8 or context.other_card:get_id() == 10) then
                return {
                    chips = 10,
                    extra = {
                        mult = 2
                    }
                }
            end
        end
    end
}