
SMODS.Joker{ --The Howling Aces
    key = "thehowlingaces",
    config = {
        extra = {
            discard_size_increase = '1',
            xmult0 = 3
        }
    },
    loc_txt = {
        ['name'] = 'The Howling Aces',
        ['text'] = {
            [1] = '{X:red,C:white}X3{} Mult.',
            [2] = '{C:red}-1{} tamanho de descarte.'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 1,
        y = 2
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = "cuplead_ilha_4",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["cuplead_cuplead_jokers"] = true },
    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            return {
                Xmult = 3
            }
        end
    end,
    
    add_to_deck = function(self, card, from_debuff)
        SMODS.change_discard_limit(-1)
    end,
    
    remove_from_deck = function(self, card, from_debuff)
        SMODS.change_discard_limit(1)
    end
}