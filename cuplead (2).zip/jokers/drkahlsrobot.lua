
SMODS.Joker{ --Dr Kahls Robot
    key = "drkahlsrobot",
    config = {
        extra = {
            mult0 = 8
        }
    },
    loc_txt = {
        ['name'] = 'Dr Kahls Robot',
        ['text'] = {
            [1] = '{C:red}+8{} Multi por carta pontuada. Se a mão jogada',
            [2] = 'conter uma {C:attention}Trinca{} destrói todas as cartas.'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 4,
        y = 1
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 6,
    rarity = "cuplead_ilha_3",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["cuplead_mycustom_jokers"] = true },
    
    calculate = function(self, card, context)
        if context.destroy_card and context.destroy_card.should_destroy  then
            return { remove = true }
        end
        if context.individual and context.cardarea == G.play  then
            context.other_card.should_destroy = false
            if next(context.poker_hands["Three of a Kind"]) then
                context.other_card.should_destroy = true
                return {
                    message = "Destroyed!"
                }
            end
        end
        if context.cardarea == G.jokers and context.joker_main  then
            return {
                mult = 8
            }
        end
    end
}