
SMODS.Joker{ --Sally Stageplay
    key = "sallystageplay",
    config = {
        extra = {
            chips0 = 50,
            mult0 = 15
        }
    },
    loc_txt = {
        ['name'] = 'Sally Stageplay',
        ['text'] = {
            [1] = 'Ao jogar um {C:attention}Full House{} ganha',
            [2] = '{C:blue}+50{} Fichas e {C:red}+15{} Multi.'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 2,
        y = 1
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 6,
    rarity = "cuplead_ilha_3",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["cuplead_mycustom_jokers"] = true },
    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if context.scoring_name == "Full House" then
                return {
                    chips = 50,
                    extra = {
                        mult = 15
                    }
                }
            end
        end
    end
}