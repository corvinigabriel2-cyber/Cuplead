
SMODS.Joker{ --Carla Maria
    key = "carlamaria",
    config = {
        extra = {
            chips0 = 20,
            xmult0 = 1.5
        }
    },
    loc_txt = {
        ['name'] = 'Carla Maria',
        ['text'] = {
            [1] = 'Cartas de {C:attention}Pedra{} dão {C:blue}+20{} Fichas e',
            [2] = '{X:red,C:white}X1.5{} Mult quando pontuadas.'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 5,
        y = 1
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 6,
    rarity = "cuplead_ilha_3",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["cuplead_mycustom_jokers"] = true },
    
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if SMODS.get_enhancements(context.other_card)["m_stone"] == true then
                return {
                    chips = 20,
                    extra = {
                        Xmult = 1.5
                    }
                }
            end
        end
    end
}