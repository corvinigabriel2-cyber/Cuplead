
SMODS.Joker{ --Ribby and Croaks
    key = "ribbyandcroaks",
    config = {
        extra = {
            odds = 4,
            xmult0 = 3
        }
    },
    loc_txt = {
        ['name'] = 'Ribby and Croaks',
        ['text'] = {
            [1] = 'Chance de {C:green}1 em 4{} de dar',
            [2] = '{X:red,C:white}X3{} Mult no final da mão jogada.'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 4,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 4,
    rarity = "cuplead_ilha_1",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["cuplead_mycustom_jokers"] = true },
    
    loc_vars = function(self, info_queue, card)
        
        local new_numerator, new_denominator = SMODS.get_probability_vars(card, 1, card.ability.extra.odds, 'j_cuplead_ribbyandcroaks') 
        return {vars = {new_numerator, new_denominator}}
    end,
    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if true then
                if SMODS.pseudorandom_probability(card, 'group_0_aa251af3', 1, card.ability.extra.odds, 'j_cuplead_ribbyandcroaks', false) then
                    SMODS.calculate_effect({Xmult = 3}, card)
                end
            end
        end
    end
}