
SMODS.Joker{ --Esther Winchester
    key = "estherwinchester",
    config = {
        extra = {
            mult0 = 15
        }
    },
    loc_txt = {
        ['name'] = 'Esther Winchester',
        ['text'] = {
            [1] = '{C:red}+15{} Mult se a mão jogada conter apenas',
            [2] = 'os {C:attention}naipes{} de {C:hearts}Copas{} ou {C:diamonds}Ouros{}.'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 3,
        y = 2
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 6,
    rarity = "cuplead_ilha_4",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["cuplead_cuplead_jokers"] = true },
    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if (function()
                local count = 0
                for _, playing_card in pairs(context.scoring_hand or {}) do
                    if true then
                        count = count + 1
                    end
                end
                return count == #context.scoring_hand
            end)() then
                return {
                    mult = 15
                }
            end
        end
    end
}