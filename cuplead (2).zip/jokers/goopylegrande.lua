
SMODS.Joker{ --Goopy Le Grande
    key = "goopylegrande",
    config = {
        extra = {
            chips0 = 60,
            chips = 20
        }
    },
    loc_txt = {
        ['name'] = 'Goopy Le Grande',
        ['text'] = {
            [1] = '{C:blue}+20{} Fichas. se a mão jogada for',
            [2] = 'uma {C:attention}Carta Alta{}, {C:blue}+60{} Fichas.'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 1,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 4,
    rarity = "cuplead_ilha_1",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["cuplead_mycustom_jokers"] = true },
    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if context.scoring_name == "High Card" then
                return {
                    chips = 60
                }
            else
                return {
                    chips = 20
                }
            end
        end
    end
}