
SMODS.Joker{ --The Devil
    key = "thedevil",
    config = {
        extra = {
            hand_size_increase = '1',
            xmult0 = 4
        }
    },
    loc_txt = {
        ['name'] = 'The Devil',
        ['text'] = {
            [1] = '{X:red,C:white}X4{} Mult.',
            [2] = '{C:red}-1{} tamanho de mão.'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 8,
        y = 1
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 10,
    rarity = "cuplead_ilha_infernal",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["cuplead_mycustom_jokers"] = true },
    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            return {
                Xmult = 4
            }
        end
    end,
    
    add_to_deck = function(self, card, from_debuff)
        G.hand:change_size(-1)
    end,
    
    remove_from_deck = function(self, card, from_debuff)
        G.hand:change_size(1)
    end
}