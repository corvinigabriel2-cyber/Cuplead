
SMODS.Joker{ --The Root Pack
    key = "therootpack",
    config = {
        extra = {
            A = 0,
            clubsindeck = 0
        }
    },
    loc_txt = {
        ['name'] = 'The Root Pack',
        ['text'] = {
            [1] = '{C:red}+2{} Mult para cada carta com o',
            [2] = 'naipe de {C:clubs}Paus{} no baralho.',
            [3] = '{C:inactive}(Atualmente:{} {C:mult}+#1#{} {C:inactive}Mult){}.'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 0,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 4,
    rarity = "cuplead_ilha_1",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["cuplead_mycustom_jokers"] = true },
    
    loc_vars = function(self, info_queue, card)
        
    return {vars = {card.ability.extra.A, ((function() local count = 0; for _, card in ipairs(G.playing_cards or {}) do if card.base.suit == 'Clubs' then count = count + 1 end end; return count end)()) * 2}}
    end,
    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            return {
            mult = ((function() local count = 0; for _, card in ipairs(G.playing_cards or {}) do if card.base.suit == 'Clubs' then count = count + 1 end end; return count end)()) * 2
            }
        end
        if context.after and context.cardarea == G.jokers  then
            return {
                func = function()
                card.ability.extra.A = ((function() local count = 0; for _, card in ipairs(G.playing_cards or {}) do if card.base.suit == 'Clubs' then count = count + 1 end end; return count end)()) * 2
                    return true
                end
            }
        end
    end
}