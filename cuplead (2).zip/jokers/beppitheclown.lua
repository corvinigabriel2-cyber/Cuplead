
SMODS.Joker{ --Beppi the Clown
    key = "beppitheclown",
    config = {
        extra = {
            mult0 = 12
        }
    },
    loc_txt = {
        ['name'] = 'Beppi the Clown',
        ['text'] = {
            [1] = 'Ao jogar uma mão muda',
            [2] = 'o {C:attention}naipe{} de todas as cartas.',
            [3] = '{C:red}+12{} de Mult.'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 6,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = "cuplead_ilha_2",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["cuplead_mycustom_jokers"] = true },
    
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            local scored_card = context.other_card
            G.E_MANAGER:add_event(Event({
                func = function()
                    
                    assert(SMODS.change_base(scored_card, pseudorandom_element(SMODS.Suits, 'edit_card_suit').key, nil))
                    card_eval_status_text(scored_card, 'extra', nil, nil, nil, {message = "Card Modified!", colour = G.C.ORANGE})
                    return true
                end
            }))
        end
        if context.cardarea == G.jokers and context.joker_main  then
            return {
                mult = 12
            }
        end
    end
}