
SMODS.Joker{ --Moonshine Mob
    key = "moonshinemob",
    config = {
        extra = {
            odds = 4,
            levels0 = 1
        }
    },
    loc_txt = {
        ['name'] = 'Moonshine Mob',
        ['text'] = {
            [1] = 'Ao jogar uma mão tem uma chance de {C:green}1 em 4{}',
            [2] = 'de subir o nivel da mão jogada em {C:attention}1{}.',
            [3] = 'Ao derrotar um {C:attention}Blind de Chefe{} cria uma cópia de {C:tarot}O Tolo{}.'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 0,
        y = 2
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 4,
    rarity = "cuplead_ilha_4",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["cuplead_cuplead_jokers"] = true },
    
    loc_vars = function(self, info_queue, card)
        
        local new_numerator, new_denominator = SMODS.get_probability_vars(card, 1, card.ability.extra.odds, 'j_cuplead_moonshinemob') 
        return {vars = {new_numerator, new_denominator}}
    end,
    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if true then
                if SMODS.pseudorandom_probability(card, 'group_0_1e797584', 1, card.ability.extra.odds, 'j_cuplead_moonshinemob', false) then
                    local target_hand = (context.scoring_name or "High Card")
                    level_up_hand(card, target_hand, true, 1)
                    card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = localize('k_level_up_ex'), colour = G.C.RED})
                end
            end
        end
        if context.end_of_round and context.main_eval and G.GAME.blind.boss  then
            return {
                func = function()
                    
                    for i = 1, math.min(1, G.consumeables.config.card_limit - #G.consumeables.cards) do
                        G.E_MANAGER:add_event(Event({
                            trigger = 'after',
                            delay = 0.4,
                            func = function()
                                play_sound('timpani')
                                SMODS.add_card({ set = 'Tarot', key = 'c_fool'})                            
                                card:juice_up(0.3, 0.5)
                                return true
                            end
                        }))
                    end
                    delay(0.6)
                    
                    if created_consumable then
                        card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = localize('k_plus_tarot'), colour = G.C.PURPLE})
                    end
                    return true
                end
            }
        end
    end
}