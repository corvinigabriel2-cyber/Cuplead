
SMODS.Joker{ --Glumstone The Giant
    key = "glumstonethegiant",
    config = {
        extra = {
            chips0 = 40,
            mult0 = 10
        }
    },
    loc_txt = {
        ['name'] = 'Glumstone The Giant',
        ['text'] = {
            [1] = 'A ultima carta jogada concede {C:blue}+40{} Fichas',
            [2] = 'e {C:red}+10{} Mult, a carta é destruida.'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 9,
        y = 1
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 4,
    rarity = "cuplead_ilha_4",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["cuplead_cuplead_jokers"] = true },
    
    calculate = function(self, card, context)
        if context.destroy_card and context.destroy_card.should_destroy  then
            return { remove = true }
        end
        if context.individual and context.cardarea == G.play  then
            context.other_card.should_destroy = false
            if context.other_card == context.scoring_hand[#context.scoring_hand] then
                context.other_card.should_destroy = true
                return {
                    chips = 40,
                    extra = {
                        mult = 10,
                        extra = {
                            message = "Destroyed!",
                            colour = G.C.RED
                        }
                    }
                }
            end
        end
    end
}