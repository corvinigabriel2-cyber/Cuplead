
SMODS.Joker{ --Grim Matchstick
    key = "grimmatchstick",
    config = {
        extra = {
            C = 1,
            highcardplayed = 1
        }
    },
    loc_txt = {
        ['name'] = 'Grim Matchstick',
        ['text'] = {
            [1] = 'Ao jogar uma {C:attention}Carta Alta{} ganha {X:red,C:white}X0.5{} Mult',
            [2] = 'e destrói a carta jogada.',
            [3] = '{C:inactive}(Atualmente: {X:mult,C:white}X#1#{} {C:inactive}Mult){}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 8,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = "cuplead_ilha_2",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["cuplead_mycustom_jokers"] = true },
    
    loc_vars = function(self, info_queue, card)
        
        return {vars = {card.ability.extra.C, card.ability.extra.highcardplayed + ((G.GAME.hands['High Card'].played or 0)) * 0.5}}
    end,
    
    calculate = function(self, card, context)
        if context.destroy_card and context.destroy_card.should_destroy  then
            return { remove = true }
        end
        if context.individual and context.cardarea == G.play  then
            context.other_card.should_destroy = false
            if context.scoring_name == "High Card" then
                context.other_card.should_destroy = true
                return {
                    message = "Destroyed!"
                }
            end
        end
        if context.cardarea == G.jokers and context.joker_main  then
            return {
                Xmult = card.ability.extra.highcardplayed + (G.GAME.hands['High Card'].played) * 0.5
            }
        end
        if context.after and context.cardarea == G.jokers  then
            return {
                func = function()
                    card.ability.extra.C = (G.GAME.hands['High Card'].played) * 0.5
                    return true
                end
            }
        end
    end
}