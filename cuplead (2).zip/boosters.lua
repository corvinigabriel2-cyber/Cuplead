
SMODS.Booster {
    key = 'inkwell_pack_one',
    loc_txt = {
        name = "Inkwell Pack One",
        text = {
            [1] = 'Escolha {C:attention}1{} entre {C:attention}3{} coringas',
            [2] = 'da raridade {C:inactive}Ilha 1{}.'
        },
        group_name = "cuplead_boosters"
    },
    config = { extra = 3, choose = 1 },
    atlas = "CustomBoosters",
    pos = { x = 0, y = 0 },
    discovered = true,
    loc_vars = function(self, info_queue, card)
        local cfg = (card and card.ability) or self.config
        return {
            vars = { cfg.choose, cfg.extra }
        }
    end,
    create_card = function(self, card, i)
        return {
            set = "Joker",
            rarity = "cuplead_ilha_1",
            area = G.pack_cards,
            skip_materialize = true,
            soulable = true,
            key_append = "cuplead_inkwell_pack_one"
        }
    end,
    particles = function(self)
        -- No particles for joker packs
        end,
    }
    
    
    SMODS.Booster {
        key = 'inkwell_pack_two',
        loc_txt = {
            name = "Inkwell Pack Two",
            text = {
                [1] = 'Escolha {C:attention}1{} entre {C:attention}3{} coringas',
                [2] = 'da raridade {C:green}Ilha 2{}.'
            },
            group_name = "cuplead_boosters"
        },
        config = { extra = 3, choose = 1 },
        cost = 5,
        weight = 0.5,
        atlas = "CustomBoosters",
        pos = { x = 1, y = 0 },
        discovered = true,
        loc_vars = function(self, info_queue, card)
            local cfg = (card and card.ability) or self.config
            return {
                vars = { cfg.choose, cfg.extra }
            }
        end,
        create_card = function(self, card, i)
            return {
                set = "Joker",
                rarity = "cuplead_ilha_2",
                area = G.pack_cards,
                skip_materialize = true,
                soulable = true,
                key_append = "cuplead_inkwell_pack_two"
            }
        end,
        particles = function(self)
            -- No particles for joker packs
            end,
        }
        
        
        SMODS.Booster {
            key = 'inkwell_pack_tree',
            loc_txt = {
                name = "Inkwell Pack Tree",
                text = {
                    [1] = 'Escolha {C:attention}1{} entre {C:attention}3{} coringas',
                    [2] = 'da raridade {C:uncommon}Ilha 3{}.'
                },
                group_name = "cuplead_boosters"
            },
            config = { extra = 3, choose = 1 },
            cost = 6,
            weight = 0.5,
            atlas = "CustomBoosters",
            pos = { x = 2, y = 0 },
            discovered = true,
            loc_vars = function(self, info_queue, card)
                local cfg = (card and card.ability) or self.config
                return {
                    vars = { cfg.choose, cfg.extra }
                }
            end,
            create_card = function(self, card, i)
                return {
                    set = "Joker",
                    rarity = "cuplead_ilha_3",
                    area = G.pack_cards,
                    skip_materialize = true,
                    soulable = true,
                    key_append = "cuplead_inkwell_pack_tree"
                }
            end,
            particles = function(self)
                -- No particles for joker packs
                end,
            }
            
            
            SMODS.Booster {
                key = 'infernal_inkwell_pack',
                loc_txt = {
                    name = "Infernal Inkwell Pack",
                    text = {
                        [1] = 'Escolha {C:attention}1{} entre {C:attention}2{} coringas da',
                        [2] = 'raridade {C:hearts}Ilha Infernal{}.'
                    },
                    group_name = "cuplead_boosters"
                },
                config = { extra = 2, choose = 1 },
                cost = 7,
                weight = 0.25,
                atlas = "CustomBoosters",
                pos = { x = 3, y = 0 },
                discovered = true,
                loc_vars = function(self, info_queue, card)
                    local cfg = (card and card.ability) or self.config
                    return {
                        vars = { cfg.choose, cfg.extra }
                    }
                end,
                create_card = function(self, card, i)
                    return {
                        set = "Joker",
                        rarity = "cuplead_ilha_infernal",
                        area = G.pack_cards,
                        skip_materialize = true,
                        soulable = true,
                        key_append = "cuplead_infernal_inkwell_pack"
                    }
                end,
                particles = function(self)
                    -- No particles for joker packs
                    end,
                }
                
                
                SMODS.Booster {
                    key = 'inkwell_pack_four',
                    loc_txt = {
                        name = "Inkwell Pack Four",
                        text = {
                            [1] = 'Escolha {C:attention}1{} entre {C:attention}4{} coringas',
                            [2] = 'da raridade {C:blue}Ilha 4{}.'
                        },
                        group_name = "cuplead_boosters"
                    },
                    config = { extra = 3, choose = 1 },
                    cost = 7,
                    weight = 0.25,
                    atlas = "CustomBoosters",
                    pos = { x = 4, y = 0 },
                    discovered = true,
                    loc_vars = function(self, info_queue, card)
                        local cfg = (card and card.ability) or self.config
                        return {
                            vars = { cfg.choose, cfg.extra }
                        }
                    end,
                    create_card = function(self, card, i)
                        return {
                            set = "Joker",
                            rarity = "cuplead_ilha_4",
                            area = G.pack_cards,
                            skip_materialize = true,
                            soulable = true,
                            key_append = "cuplead_inkwell_pack_four"
                        }
                    end,
                    particles = function(self)
                        -- No particles for joker packs
                        end,
                    }
                    