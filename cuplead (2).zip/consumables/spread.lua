
SMODS.Consumable {
    key = 'spread',
    set = 'Spectral',
    pos = { x = 1, y = 0 },
    loc_txt = {
        name = 'Spread',
        text = {
            [1] = 'Cria {C:attention}2{} cópias de uma carta selecionada.'
        }
    },
    cost = 3,
    unlocked = true,
    discovered = true,
    hidden = false,
    can_repeat_soul = false,
    atlas = 'CustomConsumables',
    use = function(self, card, area, copier)
        local used_card = copier or card
        if to_big(#G.hand.highlighted) == to_big(1) then
        end
    end,
    can_use = function(self, card)
        return (to_big(#G.hand.highlighted) == to_big(1))
    end
}