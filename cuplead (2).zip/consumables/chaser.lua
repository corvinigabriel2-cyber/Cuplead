
SMODS.Consumable {
    key = 'chaser',
    set = 'Tarot',
    pos = { x = 2, y = 0 },
    loc_txt = {
        name = 'Chaser',
        text = {
            [1] = 'Seleciona {C:attention}1{} carta e a copia.'
        }
    },
    cost = 6,
    unlocked = true,
    discovered = true,
    hidden = false,
    can_repeat_soul = false,
    atlas = 'CustomConsumables',
    use = function(self, card, area, copier)
        local used_card = copier or card
        if to_big(#G.hand.highlighted) == to_big(1) then
        end
    end,
    can_use = function(self, card)
        return (to_big(#G.hand.highlighted) == to_big(1))
    end
}