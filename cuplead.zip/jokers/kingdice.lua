
SMODS.Joker{ --King Dice
    key = "kingdice",
    config = {
        extra = {
            odds = 4,
            odds2 = 8,
            odds3 = 16,
            repetitions0 = 1,
            repetitions = 2,
            repetitions2 = 4
        }
    },
    loc_txt = {
        ['name'] = 'King Dice',
        ['text'] = {
            [1] = 'Chance de {C:green}1 em 4{} da carta reativar {C:attention}1{} vez adicional.',
            [2] = 'Chance de {C:green}1 em 8{} da carta reativar {C:attention}2{} vezes adicionais.',
            [3] = 'Chance de {C:green}1 em 16{} da carta reativar {C:attention}4{} vezes adicionais.'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 7,
        y = 1
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 10,
    rarity = "cuplead_ilha_infernal",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["cuplead_mycustom_jokers"] = true },
    
    loc_vars = function(self, info_queue, card)
        
        local new_numerator, new_denominator = SMODS.get_probability_vars(card, 1, card.ability.extra.odds, 'j_cuplead_kingdice')
        local new_numerator2, new_denominator2 = SMODS.get_probability_vars(card, 1, card.ability.extra.odds2, 'j_cuplead_kingdice')
        local new_numerator3, new_denominator3 = SMODS.get_probability_vars(card, 1, card.ability.extra.odds3, 'j_cuplead_kingdice')
        return {vars = {new_numerator, new_denominator, new_numerator2, new_denominator2, new_numerator3, new_denominator3}}
    end,
    
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if true then
                if SMODS.pseudorandom_probability(card, 'group_0_9c94c333', 1, card.ability.extra.odds, 'j_cuplead_kingdice', false) then
                    
                    return {repetitions = 1}
                end
                if SMODS.pseudorandom_probability(card, 'group_1_081380d2', 1, card.ability.extra.odds2, 'j_cuplead_kingdice', false) then
                    
                    return {repetitions = 2}
                end
                if SMODS.pseudorandom_probability(card, 'group_2_915f6f9a', 1, card.ability.extra.odds3, 'j_cuplead_kingdice', false) then
                    
                    return {repetitions = 4}
                end
            end
        end
    end
}