
SMODS.Voucher {
    key = 'astral_cookie',
    pos = { x = 6, y = 0 },
    config = { 
        extra = {
            discards0 = 1,
            hand_size0 = 2
        } 
    },
    loc_txt = {
        name = 'Astral Cookie',
        text = {
            [1] = '{C:attention}+2{} tamanho de mão.',
            [2] = '{C:red}-1{} de descarte.'
        },
        unlock = {
            [1] = 'Unlocked by default.'
        }
    },
    cost = 10,
    unlocked = true,
    discovered = true,
    no_collection = false,
    can_repeat_soul = false,
    atlas = 'CustomVouchers',
    redeem = function(self, card)
        G.GAME.round_resets.discards = G.GAME.round_resets.discards - 1
        ease_discard(-1)
        return {
            
            G.E_MANAGER:add_event(Event({
                func = function()
                    
                    
                    G.hand:change_size(2)
                    return true
                end
            }))
        }
    end
}